package com.example.tugasbkpm.model;

import androidx.recyclerview.widget.RecyclerView;

public class MahasiswaAdapter{

}
